import pygame
import sys

pygame.init()

#Screen window size
screen_width, screen_height = 800, 600
screen = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption("Cash Machine")

#Loads button images
login_button = pygame.image.load("Login.png")
exit_button = pygame.image.load("Exit.png")
withdraw_button = pygame.image.load("Withdraw.png")
five_pounds = pygame.image.load("5.png")
ten_pounds = pygame.image.load("10.png")
twenty_pounds = pygame.image.load("20.png")
fifty_pounds = pygame.image.load("50.png")

#Button sizes
button_width, button_height = 200, 80
login_button = pygame.transform.smoothscale(login_button, (button_width, button_height))
exit_button = pygame.transform.smoothscale(exit_button, (button_width, button_height))
withdraw_button = pygame.transform.smoothscale(withdraw_button, (button_width, button_height))
five_pounds = pygame.transform.smoothscale(five_pounds, (button_width, button_height))
ten_pounds = pygame.transform.smoothscale(ten_pounds, (button_width, button_height))
twenty_pounds = pygame.transform.smoothscale(twenty_pounds, (button_width, button_height))
fifty_pounds = pygame.transform.smoothscale(fifty_pounds, (button_width, button_height))

#Position of buttons
login_rectangle = login_button.get_rect(center=(screen_width // 2, screen_height // 2 - 50))
exit_rectangle = exit_button.get_rect(center=(screen_width // 2, screen_height // 2 + 150))
withdraw_rectangle = withdraw_button.get_rect(center=(screen_width // 2, screen_height // 2 - 50))

space = 110 #Acts as a buffer between buttons adding spacing
five_rectangle = five_pounds.get_rect(center=(screen_width // 2 - space, screen_height // 2 - space))
ten_rectangle = ten_pounds.get_rect(center=(screen_width // 2 + space, screen_height // 2 - space))
twenty_rectangle = twenty_pounds.get_rect(center=(screen_width // 2 - space, screen_height // 3 + space))
fifty_rectangle = fifty_pounds.get_rect(center=(screen_width // 2 + space, screen_height // 3 + space))
exit_rectangle_withdraw = exit_button.get_rect(center=(screen_width // 2, screen_height // 2 + 200))

#Font and size 
font = pygame.font.SysFont("TimesNewRoman", 36)
title_font = pygame.font.SysFont("Arial", 36)

#PIN box size
input_box = pygame.Rect(screen_width // 2 - 100, screen_height // 2 - 100, 300, 50)
colour_idle = pygame.Color('darkred')
colour_clicked = pygame.Color('red')
colour = colour_idle
active = False
text = ""
clock = pygame.time.Clock()

current_screen = "menu"
balance = 1000  #Balance value

running = True
while running:
    screen.fill((0, 0, 0))

    if current_screen == "menu": #Screen state
    
        screen.blit(login_button, login_rectangle)
        screen.blit(exit_button, exit_rectangle)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.MOUSEBUTTONDOWN:
                if login_rectangle.collidepoint(event.pos):
                    current_screen = "login" #Go to login screen
                elif exit_rectangle.collidepoint(event.pos):
                    running = False

    elif current_screen == "login":
        title_surface = title_font.render("Enter your card PIN", True, pygame.Color('red'))
        screen.blit(title_surface, (screen_width // 2 - title_surface.get_width() // 2, screen_height // 2 - 150))

        txt_surface = font.render(text, True, colour)
        width = max(200, txt_surface.get_width() + 10)
        input_box.width = width
        screen.blit(txt_surface, (input_box.x + 5, input_box.y + 5))
        pygame.draw.rect(screen, colour, input_box, 3)#Text box attributes 

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.MOUSEBUTTONDOWN:
                if input_box.collidepoint(event.pos):#Checks if the text box has been clicked
                    active = not active
                    colour = colour_clicked if active else colour_idle #Box highlights when clicked
                else:
                    active = False
                    colour = colour_idle
            if event.type == pygame.KEYDOWN:
                if active:
                    if event.key == pygame.K_RETURN:
                        if text == "1234": #Correct PIN
                            current_screen = "balance"
                        else:
                            print("Incorrect PIN")#PIN error checking
                        text = ''
                    elif event.key == pygame.K_BACKSPACE:
                        text = text[:-1]
                    else:
                        text += event.unicode

    elif current_screen == "balance":
        balance_surface = title_font.render(f"Balance: £{balance}", True, pygame.Color('red'))
        screen.blit(balance_surface, (screen_width // 2 - balance_surface.get_width() // 2, screen_height // 2 - 200))
        screen.blit(withdraw_button, withdraw_rectangle)
        screen.blit(exit_button, exit_rectangle)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.MOUSEBUTTONDOWN:
                if withdraw_rectangle.collidepoint(event.pos):
                    current_screen = "withdraw"#Go to  the withdraw screen
                elif exit_rectangle.collidepoint(event.pos):
                    running = False

    elif current_screen == "withdraw":
        balance_surface = title_font.render(f"Balance: £{balance}", True, pygame.Color('red'))#Renders balance text
        screen.blit(balance_surface, (screen_width // 2 - balance_surface.get_width() // 2, screen_height // 2 - 200))#Balance text position

        #Draws the cash buttons and exit button
        screen.blit(five_pounds, five_rectangle)
        screen.blit(ten_pounds, ten_rectangle)
        screen.blit(twenty_pounds, twenty_rectangle)
        screen.blit(fifty_pounds, fifty_rectangle)
        screen.blit(exit_button, exit_rectangle_withdraw)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.MOUSEBUTTONDOWN:
                if five_rectangle.collidepoint(event.pos):
                    if balance >= 5:#Checks if the balance is high enough to withdraw 
                        balance -= 5
                    else:
                        print("Balance too low")
                elif ten_rectangle.collidepoint(event.pos):
                    if balance >= 10:
                        balance -= 10
                    else:
                        print("Balance too low")
                elif twenty_rectangle.collidepoint(event.pos):
                    if balance >= 20:
                        balance -= 20
                    else:
                        print("Balance too low")
                elif fifty_rectangle.collidepoint(event.pos):
                    if balance >= 50:
                        balance -= 50
                    else:
                        print("Balance too low")
                elif exit_rectangle_withdraw.collidepoint(event.pos):
                    current_screen = "balance" 

    pygame.display.update()#Updates the screen
    clock.tick(30)

pygame.quit()
sys.exit()